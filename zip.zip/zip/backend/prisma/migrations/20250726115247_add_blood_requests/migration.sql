-- AlterTable
ALTER TABLE "users" ADD COLUMN "telegramChatId" TEXT;
